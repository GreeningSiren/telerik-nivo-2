function initcoords(level) {
    if (level == 1) {
        dx= 0
        myX = 290.5
        myY = 520
        kaduramog = 2
        brKotii = 4
        kotiqX[0] = 69
        kotiqY[0] = 450
        kotiqX[1] = 260
        kotiqY[1] = 300
        kotiqX[2] = 515
        kotiqY[2] = 200
        kotiqX[3] = 165
        kotiqY[3] = 100
        celX = 180
        celY = 35
    }
    if(level == 2) {
        dx = 0
        myX = 29.5
        myY = 520
        kaduramog = 1
        brKotii = 5
        kotiqX[0] = 188
        kotiqY[0] = 445
        kotiqX[1] = 15
        kotiqY[1] = 350
        kotiqX[2] = 340
        kotiqY[2] = 290
        kotiqX[3] = 470
        kotiqY[3] = 150
        kotiqX[4] = 700
        kotiqY[4] = 75
        celX = 715
        celY = 5
    }
    
}