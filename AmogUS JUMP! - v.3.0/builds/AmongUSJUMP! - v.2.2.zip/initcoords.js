function initcoords(level) {
    if (level == 1) {
        brKotii = 2
        kotiqX[0] = 69
        kotiqY[0] = 450
        kotiqX[1] = 260
        kotiqY[1] = 300
    }
}