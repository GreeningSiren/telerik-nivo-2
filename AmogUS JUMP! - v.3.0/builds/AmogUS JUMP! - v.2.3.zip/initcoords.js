function initcoords(level) {
    if (level == 1) {
        dx= 0
        myX = 290.5
        myY = 520
        kaduramog = 2
        brKotii = 4
        kotiqX[0] = 69
        kotiqY[0] = 450
        kotiqX[1] = 260
        kotiqY[1] = 300
        kotiqX[2] = 515
        kotiqY[2] = 200
        kotiqX[3] = 165
        kotiqY[3] = 100
        celX = 180
        celY = 35
    }
    
}